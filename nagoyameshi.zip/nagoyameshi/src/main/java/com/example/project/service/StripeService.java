package com.example.project.service;

import com.stripe.model.Customer;
import com.stripe.model.PaymentMethod;
import com.stripe.model.Subscription;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.PaymentMethodAttachParams;
import com.stripe.param.SubscriptionCreateParams;

import org.springframework.stereotype.Service;

@Service
public class StripeService {

    public Customer createCustomer(String email) throws Exception {
        CustomerCreateParams params = CustomerCreateParams.builder()
            .setEmail(email)
            .build();
        return Customer.create(params);
    }

    public Subscription createSubscription(String customerId, String paymentMethodId, String priceId) throws Exception {
        SubscriptionCreateParams subscriptionParams = SubscriptionCreateParams.builder()
            .setCustomer(customerId)
            .addItem(SubscriptionCreateParams.Item.builder()
                .setPrice(priceId)
                .build())
            .setDefaultPaymentMethod(paymentMethodId)
            .build();
        return Subscription.create(subscriptionParams);
    }
}
