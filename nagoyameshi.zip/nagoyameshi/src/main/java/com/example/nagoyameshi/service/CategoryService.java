package com.example.nagoyameshi.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.StoreCategory;
import com.example.nagoyameshi.form.CategoryEditForm;
import com.example.nagoyameshi.form.CategoryRegisterForm;
import com.example.nagoyameshi.repository.CategoryRepository;
import com.example.nagoyameshi.repository.StoreCategoryRepository;
import com.example.nagoyameshi.repository.StoreRepository;

@Service
public class CategoryService {
	private final CategoryRepository categoryRepository;
	private final StoreRepository storeRepository;
	private final StoreCategoryRepository storeCategoryRepository;
	
	public CategoryService(CategoryRepository categoryRepository, StoreRepository storeRepository, StoreCategoryRepository storeCategoryRepository) {
		this.categoryRepository = categoryRepository;
		this.storeRepository = storeRepository;
		this.storeCategoryRepository = storeCategoryRepository;
	}
	
	@Transactional
	public void create(CategoryRegisterForm categoryRegisterForm) {
		Category category = new Category();
		
		category.setName(categoryRegisterForm.getName());
		
		categoryRepository.save(category);
		
        for (Integer storeId : categoryRegisterForm.getStores()) {
    		StoreCategory storeCategory = new StoreCategory();
        	Store store = storeRepository.findById(storeId).orElseThrow(() -> new IllegalArgumentException("Category not found with id: " + storeId));
        	storeCategory.setStore(store);
        	storeCategory.setCategory(category);
        	storeCategoryRepository.save(storeCategory);
        }	
	}
	
	@Transactional
	public void update(CategoryEditForm categoryEditForm) {
		Category category = categoryRepository.getReferenceById(categoryEditForm.getId());
		
		category.setName(categoryEditForm.getName());
		
		categoryRepository.save(category);
		
		storeCategoryRepository.deleteByCategoryId(category.getId());
        for (Integer storeId : categoryEditForm.getStores()) {
    		StoreCategory storeCategory = new StoreCategory();
        	Store store = storeRepository.findById(storeId).orElseThrow(() -> new IllegalArgumentException("Category not found with id: " + storeId));
        	storeCategory.setStore(store);
        	storeCategory.setCategory(category);
        	storeCategoryRepository.save(storeCategory);
        }	
	}
	
	@Transactional
	public void delete(Integer categoryId) {
		storeCategoryRepository.deleteByCategoryId(categoryId);
		categoryRepository.deleteById(categoryId);
	}
	
	// 各カテゴリに対応する店舗名をカンマ区切りで表示
	public Map<Category, String> getCategoryStoreNames() {
        List<Category> categories = categoryRepository.findAll();
        return categories.stream().collect(Collectors.toMap(
            category -> category,
            category -> {
                List<Store> stores = storeCategoryRepository.findStoresByCategoryId(category.getId());
                if (stores.isEmpty()) {
                	return "―";
                } else {
                	return stores.stream().map(Store::getName).collect(Collectors.joining(", "));
                }
            }
        ));
    }
	
	// 各カテゴリに対応する店舗数を表示
	public Map<Category, Integer> getCategoryStoreCount() {
        List<Category> categories = categoryRepository.findAll();
        return categories.stream().collect(Collectors.toMap(
            category -> category,
            category -> {
                List<Store> stores = storeCategoryRepository.findStoresByCategoryId(category.getId());
                return stores.size();
            }
        ));
    }
}
