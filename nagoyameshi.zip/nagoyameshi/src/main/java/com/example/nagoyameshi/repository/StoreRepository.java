package com.example.nagoyameshi.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.nagoyameshi.entity.Store;

public interface StoreRepository extends JpaRepository<Store, Integer> {
	Page<Store> findByNameLike(String keyword, Pageable pageable);
	
	// 並び替え: 新着順
	Page<Store> findAllByOrderByCreatedAtDesc(Pageable pageable);
	
    @Query("""
            SELECT DISTINCT s FROM Store s
            LEFT JOIN StoreCategory sc ON s.id = sc.store.id
            LEFT JOIN Category c ON sc.category.id = c.id
            WHERE (s.name LIKE %:keyword% OR c.name LIKE %:keyword%)
            ORDER BY s.createdAt DESC
    """)
    Page<Store> findStoresByKeywordOrderByCreatedAtDesc(String keyword, Pageable pageable);

    // 並び替え: 価格が安い順
    Page<Store> findAllByOrderByMinPriceAsc(Pageable pageable);
    
    @Query("""
            SELECT DISTINCT s FROM Store s
            LEFT JOIN StoreCategory sc ON s.id = sc.store.id
            LEFT JOIN Category c ON sc.category.id = c.id
            WHERE (:keyword IS NULL OR s.name LIKE %:keyword% OR c.name LIKE %:keyword%)
            ORDER BY s.minPrice ASC
    """)
    Page<Store> findStoresByKeywordOrderByMinPriceAsc(String keyword, Pageable pageable);
    
    // 並び替え: レビューの平均スコアが高い順
    @Query("""
            SELECT DISTINCT s FROM Store s
            LEFT JOIN StoreCategory sc ON s.id = sc.store.id
            LEFT JOIN Category c ON sc.category.id = c.id
            LEFT JOIN Review r ON s.id = r.store.id
            GROUP BY s.id
            ORDER BY AVG(r.score) DESC NULLS LAST
    """)
    Page<Store> findAllByOrderByAverageScoreDesc(Pageable pageable);
    
    @Query("""
            SELECT DISTINCT s FROM Store s
            LEFT JOIN StoreCategory sc ON s.id = sc.store.id
            LEFT JOIN Category c ON sc.category.id = c.id
            LEFT JOIN Review r ON s.id = r.store.id
            WHERE (s.name LIKE %:keyword% OR c.name LIKE %:keyword%)
            GROUP BY s.id
            ORDER BY AVG(r.score) DESC NULLS LAST
    """)
    Page<Store> findStoresByKeywordOrderByAverageScoreDesc(String keyword, Pageable pageable);
    
    // レビューの平均スコアを表示
    @Query("""
            SELECT s, AVG(r.score) AS averageScore
            FROM Store s
            LEFT JOIN Review r ON s.id = r.store.id
            GROUP BY s.id
    """)
    List<Object[]> findAllStoresWithAverageScoreRaw();
}
