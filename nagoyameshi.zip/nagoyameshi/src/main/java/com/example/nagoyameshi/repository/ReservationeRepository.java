package com.example.nagoyameshi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.nagoyameshi.entity.Reservation;

public interface ReservationeRepository extends JpaRepository<Reservation, Integer> {

}
