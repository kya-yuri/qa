package com.example.nagoyameshi.controller;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Favorite;
import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReservationInputForm;
import com.example.nagoyameshi.repository.FavoriteRepository;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreCategoryRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.StoreService;

@Controller
@RequestMapping("/stores")
public class StoreController {
    private final StoreRepository storeRepository;
    private final StoreService storeService;
    private final ReviewRepository reviewRepository;
    private final FavoriteRepository favoriteRepository;
    private final StoreCategoryRepository storeCategoryRepository;
    
    public StoreController(StoreRepository storeRepository, StoreService storeService, ReviewRepository reviewRepository, FavoriteRepository favoriteRepository, StoreCategoryRepository storeCategoryRepository) {
        this.storeRepository = storeRepository;
        this.storeService = storeService;        		
        this.reviewRepository = reviewRepository;
        this.favoriteRepository = favoriteRepository;
        this.storeCategoryRepository = storeCategoryRepository;
    }     
  
    @GetMapping
    public String index(@RequestParam(name = "keyword", required = false) String keyword,
                        @RequestParam(name = "order", required = false) String order,
                        @PageableDefault(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,
                        Model model){
        Page<Store> storePage;
        Map<Store, String> storeAverageScoreMapString = storeService.getStringStoreAverageScore();
        Map<Store, Double> storeAverageScoreMapDouble = storeService.getDoubleStoreAverageScore();
                
        if (keyword != null && !keyword.isEmpty()) {
            if (order != null && order.equals("minPriceAsc")) {
                storePage = storeRepository.findStoresByKeywordOrderByMinPriceAsc(keyword, pageable);
            } else 
            if (order != null && order.equals("scoreDesc")) {
                storePage = storeRepository.findStoresByKeywordOrderByAverageScoreDesc(keyword, pageable);
            } else {
            	storePage = storeRepository.findStoresByKeywordOrderByCreatedAtDesc(keyword, pageable);
            }
        } else {
            if (order != null && order.equals("minPriceAsc")) {
                storePage = storeRepository.findAllByOrderByMinPriceAsc(pageable);
            } else      	
            if (order != null && order.equals("scoreDesc")) {
                storePage = storeRepository.findAllByOrderByAverageScoreDesc(pageable);
            } else {
            	storePage = storeRepository.findAllByOrderByCreatedAtDesc(pageable);
            }
        }                
        
        model.addAttribute("storePage", storePage);
        model.addAttribute("keyword", keyword);
        model.addAttribute("order", order);
        model.addAttribute("storeService", storeService);
        model.addAttribute("storeAverageScoreMapString", storeAverageScoreMapString);
        model.addAttribute("storeAverageScoreMapDouble", storeAverageScoreMapDouble);
        
        return "stores/index";
    }
    
    @GetMapping("/{id}")
    public String show(@PathVariable(name = "id") Integer id, 
    					Model model, 
    					@AuthenticationPrincipal UserDetailsImpl userDetailsImpl) {
        Store store = storeRepository.getReferenceById(id);
		List<Category> categories = storeCategoryRepository.findCategoriesByStoreId(id);
        List<Review> newReviews = reviewRepository.findTop4ByStoreOrderByCreatedAtDesc(store);  
              
        model.addAttribute("store", store);   
        model.addAttribute("reservationInputForm", new ReservationInputForm());
        model.addAttribute("newReviews", newReviews);
		model.addAttribute("categories", categories);
		model.addAttribute("strMinPrice", storeService.formatWithCommas(store.getMinPrice()));
		model.addAttribute("strMaxPrice", storeService.formatWithCommas(store.getMaxPrice()));
        model.addAttribute("openHour", "09:00");  
        model.addAttribute("closedHour", "18:00");
        // model.addAttribute("openHour", store.getOpenHour().toString());  
        // model.addAttribute("closedHour", store.getClosedHour().toString());
       
        if (userDetailsImpl != null) {
            User user = userDetailsImpl.getUser();    
            Review review = reviewRepository.findByStoreAndUser(store, user);      
            Favorite favorite = favoriteRepository.findByStoreAndUser(store, user);
            model.addAttribute("myReview", review);  
            model.addAttribute("favorite", favorite);
        }
                
        return "stores/show";
    } 
}
