package com.example.nagoyameshi.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.repository.StoreRepository;

@Controller
public class HomeController {
	private final StoreRepository storeRepository;
	
	public HomeController(StoreRepository storeRepository) {
		this.storeRepository = storeRepository; 
	}
	
	@GetMapping("/")
    public String index(Model model) {
		List<String> images = storeRepository.findAll().stream().map(Store::getImageName)
											.filter(imageName -> imageName != null && !imageName.isEmpty())
											.collect(Collectors.toList());
		
		model.addAttribute("images", images);
		
		return "index";
	}
}
