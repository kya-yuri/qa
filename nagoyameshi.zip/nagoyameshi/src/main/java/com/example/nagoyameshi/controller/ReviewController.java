package com.example.nagoyameshi.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.Review;
import com.example.nagoyameshi.entity.Store;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.form.ReviewEditForm;
import com.example.nagoyameshi.form.ReviewRegisterForm;
import com.example.nagoyameshi.repository.ReviewRepository;
import com.example.nagoyameshi.repository.StoreRepository;
import com.example.nagoyameshi.security.UserDetailsImpl;
import com.example.nagoyameshi.service.ReviewService;

@Controller
@RequestMapping("/stores/{storeId}/reviews")
public class ReviewController {
	private final StoreRepository storeRepository;
	private final ReviewRepository reviewRepository;
	private final ReviewService reviewService;
    
	public ReviewController(StoreRepository storeRepository, ReviewRepository reviewRepository, ReviewService reviewService) {
		this.storeRepository = storeRepository;
		this.reviewRepository = reviewRepository;
		this.reviewService = reviewService;
	}     
    
	@GetMapping
	public String index(@PathVariable(name = "storeId") Integer storeId,
						@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Direction.DESC) Pageable pageable,
						Model model) {
		Store store = storeRepository.getReferenceById(storeId);
		Page<Review> reviewPage = reviewRepository.findByStoreOrderByCreatedAtDesc(store, pageable);
        
		model.addAttribute("store", store);   
		model.addAttribute("reviewPage", reviewPage);
        
		return "reviews/index";
	} 
    
	@GetMapping("/register")
	public String register(@PathVariable(name = "storeId") Integer storeId, Model model) {
		Store store = storeRepository.getReferenceById(storeId);
        
		model.addAttribute("store", store);  
		model.addAttribute("reviewRegisterForm", new ReviewRegisterForm());
		return "reviews/register";
	}
    
	@PostMapping("/register/create")
	public String create(@PathVariable(name = "storeId") Integer storeId,
							@AuthenticationPrincipal UserDetailsImpl userDetailsImpl,     
							@ModelAttribute @Validated ReviewRegisterForm reviewRegisterForm, 
							BindingResult bindingResult,
							Model model) {       
		Store store = storeRepository.getReferenceById(storeId);
		User user = userDetailsImpl.getUser(); 
        
		if (bindingResult.hasErrors()) {
			model.addAttribute("store", store);
			return "reviews/register";
		}
        
		reviewService.create(store, user, reviewRegisterForm);
        
		return "redirect:/stores/{storeId}/reviews";
	}  
    
	@GetMapping("/{reviewId}/edit")
	public String edit(@PathVariable(name = "storeId") Integer storeId, @PathVariable(name = "reviewId") Integer reviewId, Model model) {       
		Store store = storeRepository.getReferenceById(storeId);
		Review review = reviewRepository.getReferenceById(reviewId);
		ReviewEditForm reviewEditForm = new ReviewEditForm(review.getId(), review.getScore(), review.getComment());
        
		model.addAttribute("store", store);
		model.addAttribute("review", review);
		model.addAttribute("reviewEditForm", reviewEditForm);
        
		return "reviews/edit";
	}
    
	@PostMapping("/{reviewId}/update")
	public String update(@PathVariable(name = "storeId") Integer storeId,
							@PathVariable(name = "reviewId") Integer reviewId,
							@ModelAttribute @Validated ReviewEditForm reviewEditForm, 
							BindingResult bindingResult,
							Model model) {       
		Store store = storeRepository.getReferenceById(storeId);
		Review review = reviewRepository.getReferenceById(reviewId);
        
		if (bindingResult.hasErrors()) {
			model.addAttribute("store", store);
			model.addAttribute("review", review);
			return "reviews/edit";
		}
               
		reviewService.update(reviewEditForm);
        
		return "redirect:/stores/{storeId}/reviews";
	}
    
	@PostMapping("/{reviewId}/delete")
	public String delete(@PathVariable(name = "reviewId") Integer reviewId, RedirectAttributes redirectAttributes) {        
		reviewRepository.deleteById(reviewId);
                
		redirectAttributes.addFlashAttribute("successMessage", "レビューを削除しました。");
        
		return "redirect:/stores/{storeId}";
	}   

}
